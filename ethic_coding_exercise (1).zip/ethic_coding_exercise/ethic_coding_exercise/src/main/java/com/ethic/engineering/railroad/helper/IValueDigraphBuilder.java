package com.ethic.engineering.railroad.helper;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;

import java.util.Map;
import java.util.Set;

public interface IValueDigraphBuilder {
    Set<Node> nodes();

    Map<Node, Map<Node, Double>> successorConnections();

    IValueDigraphBuilder addEdgeWithValue(Node from, Node to, Double value);

    default ValueDigraph build() {
        return new ValueDigraph(this);
    }
}
