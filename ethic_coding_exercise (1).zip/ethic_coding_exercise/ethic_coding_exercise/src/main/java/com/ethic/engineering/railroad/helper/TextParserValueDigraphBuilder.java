package com.ethic.engineering.railroad.helper;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;

import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class TextParserValueDigraphBuilder implements IValueDigraphBuilder {

    private Set<Node> nodes = new HashSet<>();
    private Map<Node, Map<Node, Double>> successorConnections = new HashMap<>();
    private final InputStream in;

    public TextParserValueDigraphBuilder(InputStream in) {
        this.in = in;
    }

    @Override
    public TextParserValueDigraphBuilder addEdgeWithValue(Node from, Node to, Double value) {
        if (Double.compare(value, 0D) <= 0D) {
            throw new IllegalArgumentException("Invalid distance for edge: " + from + ":" + to + ":" + value);
        }

        nodes.add(from);
        nodes.add(to);
        successorConnections.putIfAbsent(from, new HashMap<>());
        Double prev = successorConnections.get(from).putIfAbsent(to, value);
        if (prev != null) {
            throw new IllegalArgumentException("Duplicated edge: " + from + ":" + to + ":" + value);
        }
        return this;
    }

    @Override
    public Set<Node> nodes() {
        return nodes;
    }

    @Override
    public Map<Node, Map<Node, Double>> successorConnections() {
        return successorConnections;
    }

    @Override
    public ValueDigraph build() {
        parse();
        return IValueDigraphBuilder.super.build();
    }

    private void parse() {
        try (Scanner scanner = new Scanner(in)) {
            scanner.useDelimiter(",");
            while (scanner.hasNext()) {
                String token = scanner.next();
                if (token.length() != 3) {
                    throw new IllegalArgumentException("Got unexpected input" + token);
                }
                Double value = Double.parseDouble(token.substring(2, 3));
                addEdgeWithValue(
                        Node.of(token.substring(0, 1)),
                        Node.of(token.substring(1, 2)),
                        value
                );
            }
        }
    }
}
