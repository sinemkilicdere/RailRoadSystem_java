package com.ethic.engineering.railroad;

import com.ethic.engineering.railroad.businesslogic.*;
import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;
import com.ethic.engineering.railroad.helper.TextParserValueDigraphBuilder;
import com.ethic.engineering.railroad.helper.UserCommand;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.IntStream;

public class RailRoadAppMain {

    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 1) {
            throw new IllegalArgumentException("Wrong number of arguments, only take one file");
        }

        File initialFile = new File(args[0]);
        InputStream in = new FileInputStream(initialFile);

        ValueDigraph graph = new TextParserValueDigraphBuilder(in).build();

        new RailRoadAppMain(graph).runQueries();
    }
    // Constant for handling cases when a route is not found
    private static final String NO_SUCH_ROUTE = "NO SUCH ROUTE";

    // Declare fields for the various calculators used in the application
    private final IConnectednessChecker connectednessChecker;
    private final IDistanceOfRouteCalculator distanceOfRouteCalculator;
    private final NumberOfRoutesByStopsCalculator routeByStopsCalculator;// implementation
    private final NumberOfRoutesByDistanceCalculator routeByDistanceCalculator; // implementation

    // Constructor to initialize the calculators
    RailRoadAppMain(ValueDigraph graph) {
        this.connectednessChecker = DFSConnectednessChecker.from(graph);
        this.distanceOfRouteCalculator = DefaultDistanceOfRouteCalculator.from(graph);
        this.routeByStopsCalculator = new NumberOfRoutesByStopsCalculator(graph); // implementation
        this.routeByDistanceCalculator = new NumberOfRoutesByDistanceCalculator(graph); // implementation
    }
    // This method handles the main loop that reads and processes user queries
    private void runQueries() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter your query");
        while (sc.hasNext()) {
            String line = sc.nextLine();
            String[] tokens = line.split(" ");
            if (tokens.length == 0) {// If the user input is empty, print an error message
                System.out.println("Invalid input=" + line);
            } else {
                String commandCode = tokens[0];
                Optional<UserCommand> optionalCommand = UserCommand.getEnumByCode(commandCode); // Try to match the command code to a valid UserCommand enum value

                // If no valid command is found, prints an error message and continue to the next input
                if (optionalCommand.isEmpty()) {
                    System.out.println("Invalid command code=" + commandCode);
                    continue;
                }

                Object response = new Object();

                Node from, to;
                try {
                    switch (optionalCommand.get()) {
                        case IsConnected:// If the command is "IC" (Is Connected), check if two nodes are connected
                            from = Node.of(tokens[1]);
                            to = Node.of(tokens[2]);
                            response = this.connectednessChecker.isConnected(from, to);
                            break;
                        case DistanceOfRoute:// If the command is "DOR" (Distance Of Route), calculate the distance of a specific route
                            String routeString = tokens[1];
                            List<Node> route = IntStream.range(0, routeString.length())
                                    .mapToObj(i -> routeString.substring(i, i + 1))
                                    .map(Node::of)
                                    .toList();
                            response = this.distanceOfRouteCalculator.distanceOfRoute(route);
                            break;
                        case NumberOfRoutesByStops: // If the command is "NORS" (Number of Routes by Stops), calculate the number of routes with a maximum of 'maxStops'
                            from = Node.of(tokens[1]);// Get the starting node
                            to = Node.of(tokens[2]);// Get the destination node
                            int maxStops = Integer.parseInt(tokens[3]);
                            // Calculate the number of routes with the given stops limit using the routeByStopsCalculator
                            response = this.routeByStopsCalculator.calculate(from, to, maxStops);
                            break;
                        case NumberOfRoutesByDistance: // If the command is "NORD" (Number of Routes by Distance), calculate the number of routes with a maximum distance
                            from = Node.of(tokens[1]);// Get the starting node
                            to = Node.of(tokens[2]);// Get the destination node
                            double maxDistance = Double.parseDouble(tokens[3]);
                            // Calculate the number of routes with the given distance limit using the routeByDistanceCalculator
                            response = this.routeByDistanceCalculator.calculate(from, to, maxDistance);
                            break;

                        case Quit:
                            System.out.println("Goodbye!");
                            System.exit(0);
                    }

                    System.out.println("Output=" + toDisplayString(response));
                    System.out.println();
                } catch (Exception e) {
                    System.out.println("Invalid command=" + line);
                }
                System.out.println("Please enter your query");
            }
        }
    }

    private String toDisplayString(Object in) {
        String res = in.toString();
        if (in instanceof Optional<?>) {
            Optional<?> tmp = (Optional<?>) in;
            res = tmp.map(this::toDisplayString)
                    .orElse(NO_SUCH_ROUTE);
        } else if (in instanceof Double) {
            Double d = (Double) in;
            if (d % 1 == 0) {
                res = ((Integer) d.intValue()).toString();
            }
        }
        return res;
    }

}
