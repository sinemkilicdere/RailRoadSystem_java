package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class DFSConnectednessChecker implements IConnectednessChecker{

    private final Set<Node> visited = new HashSet<>();  // Set to keep track of visited nodes
    private final ValueDigraph graph;

    // Private constructor to initialize the graph
    private DFSConnectednessChecker(ValueDigraph graph) {
        this.graph = graph;
    }

    // Static factory method to create an instance of DFSConnectednessChecker
    public static DFSConnectednessChecker from(ValueDigraph graph) {
        Objects.requireNonNull(graph);// Ensure that the graph is not null
        return new DFSConnectednessChecker(graph);
    }

    @Override
    public boolean isConnected(Node from, Node to) {
        visited.add(from);// Mark the 'from' node as visited
        return isAnySuccessorConnected(from, to);// Start DFS from the 'from' node
    }

    // Recursive method to check connectivity using Depth First Search (DFS)
    private boolean isConnectedDFS(Node from, Node to) {
        if (from.equals(to)) { // Base case: if we've reached the target node
            return true;
        }

        if (visited.contains(from)) {// If the node has been visited, there's no path
            return false;
        }

        visited.add(from); // Mark the current node as visited
        return isAnySuccessorConnected(from, to);// Recursively check successors
    }

    // Helper method to check if any successor of the current node leads to the target node
    private boolean isAnySuccessorConnected(Node node, Node to) {
        // Iterate over the successors of the current node
        return graph.successors(node).stream()
                .anyMatch((successor) -> this.isConnectedDFS(successor, to));
    }
}
