package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;

public interface IConnectednessChecker {

    boolean isConnected(Node from, Node to);
}
