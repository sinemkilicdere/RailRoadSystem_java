package com.ethic.engineering.railroad.helper;

import java.util.Optional;

public enum UserCommand {
    IsConnected("IC"),
    DistanceOfRoute("DOR"),
    NumberOfRoutesByStops("NORS"),  // new
    NumberOfRoutesByDistance("NORD"), // for new class
    Quit("Q")
    ;

    private final String code;

    UserCommand(String code) {
        this.code = code;
    }

    public static Optional<UserCommand> getEnumByCode(String code) {
        for (UserCommand e : UserCommand.values()) {
            if (code.equals(e.code)) {
                return Optional.of(e);
            }
        }
        return Optional.empty();
    }
}
