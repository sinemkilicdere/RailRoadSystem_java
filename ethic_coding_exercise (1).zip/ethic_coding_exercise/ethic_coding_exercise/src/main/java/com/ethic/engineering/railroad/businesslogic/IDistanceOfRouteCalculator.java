package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;

import java.util.List;
import java.util.Optional;

public interface IDistanceOfRouteCalculator {
    Optional<Double> distanceOfRoute(List<Node> route);
}
