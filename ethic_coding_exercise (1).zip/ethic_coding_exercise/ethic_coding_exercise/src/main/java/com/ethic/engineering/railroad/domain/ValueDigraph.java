package com.ethic.engineering.railroad.domain;

import com.ethic.engineering.railroad.helper.IValueDigraphBuilder;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * This immutable class implements a directed graph with values(weights/distances)
 * assigned to edges.
 */
public class ValueDigraph {

    private final Set<Node> nodes;
    private final Map<Node, Map<Node, Double>> successorConnections;

    /**
     * @return all nodes in the graph
     */
    public Set<Node> nodes() {
        return nodes;
    }

    /**
     * @param node node in graph
     * @return successors of nodes
     */
    public Set<Node> successors(Node node) {
        validateNode(node);
        return successorConnections.getOrDefault(node, Collections.emptyMap()).keySet();
    }

    /**
     * @param node node in graph
     * @return a map of successors with values on the edges
     */
    public Map<Node, Double> successorWithValues(Node node) {
        validateNode(node);
        return successorConnections.getOrDefault(node, Collections.emptyMap());
    }

    private void validateNode(Node node) {
        if (!nodes().contains(node)) {
            throw new IllegalArgumentException("Invalid node=" + node);
        }
    }

    public ValueDigraph(IValueDigraphBuilder builder) {
        Objects.requireNonNull(builder.nodes());
        Objects.requireNonNull(builder.successorConnections());
        this.nodes = Set.copyOf(builder.nodes());
        this.successorConnections = Map.copyOf(builder.successorConnections());
    }
}
