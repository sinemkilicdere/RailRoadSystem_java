package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;

import java.util.*;

public class DefaultDistanceOfRouteCalculator implements IDistanceOfRouteCalculator {

    private final ValueDigraph graph; // The graph representing the railroad network

    // Private constructor to initialize the graph
    private DefaultDistanceOfRouteCalculator(ValueDigraph graph) {
        this.graph = graph;
    }

    // Static factory method to create an instance of DefaultDistanceOfRouteCalculator
    public static DefaultDistanceOfRouteCalculator from(ValueDigraph graph) {
        Objects.requireNonNull(graph);
        return new DefaultDistanceOfRouteCalculator(graph);
    }

    /**
     * Return the total distance of a given route
     *
     * @param route a list that represents the route
     * @return total distance of route
     */
    @Override
    public Optional<Double> distanceOfRoute(List<Node> route) {
        if (route == null || route.size() < 2) { // Ensure that there are at least two nodes
            return Optional.empty();
        }

        double totalDistance = 0.0;
        Iterator<Node> iterator = route.iterator();
        Node current = iterator.next();// Start from the first node in the route

        // Iterate through the route and calculate the total distance
        while (iterator.hasNext()) {
            Node next = iterator.next();
            // Get the successors of the current node (i.e., connected nodes)
            Map<Node, Double> connections = graph.successorWithValues(current);

            // If there is no direct connection to the next node, the route is invalid
            if (!connections.containsKey(next)) {
                return Optional.empty(); // Route does not exist
            }
            totalDistance += connections.get(next); // Add the distance to the tota
            current = next;  // Move to the next node in the route
        }
        // Return the total distance as an Optional
        return Optional.of(totalDistance);
    }

}
