package com.ethic.engineering.railroad.domain;

import java.util.Objects;

/**
 * immutable representation of Node(Station)
 */
public class Node {

    private final String name;

    private Node(String name) {
        this.name = name;
        Objects.requireNonNull(this.name);
    }

    public static Node of(String name) {
        return new Node(name);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Node)) {
            return false;
        }
        Node other = (Node) obj;
        return name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public String toString() {
        return "[" + name + "]";
    }
}
