package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;

import java.util.Map;

public class NumberOfRoutesByDistanceCalculator {
    private final ValueDigraph graph;

    // Constructor to initialize the graph
    public NumberOfRoutesByDistanceCalculator(ValueDigraph graph) {
        this.graph = graph;
    }

    public int calculate(Node start, Node end, double maxDistance) {
        return findRoutes(start, end, maxDistance, 0.0);// Call the recursive method to find routes
    }
    // Recursive method to find all possible routes with a total distance less than maxDistance
    private int findRoutes(Node current, Node end, double maxDistance, double currentDistance) {
        if (currentDistance >= maxDistance) return 0;// Stop if we've exceeded the maxDistance
        int count = current.equals(end) && currentDistance > 0 ? 1 : 0;// If we reach the destination, count this route

        // Explore each successor of the current node and check their routes
        for (Map.Entry<Node, Double> entry : graph.successorWithValues(current).entrySet()) {
            count += findRoutes(entry.getKey(), end, maxDistance, currentDistance + entry.getValue());
        }

        return count;// Return the total number of valid routes
    }
}
