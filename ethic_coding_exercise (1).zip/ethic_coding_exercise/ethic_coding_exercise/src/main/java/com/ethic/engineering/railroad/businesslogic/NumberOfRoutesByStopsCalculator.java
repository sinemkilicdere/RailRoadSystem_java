package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;

public class NumberOfRoutesByStopsCalculator {
    private final ValueDigraph graph;

    // Constructor to initialize the graph
    public NumberOfRoutesByStopsCalculator(ValueDigraph graph) {
        this.graph = graph;
    }

    public int calculate(Node start, Node end, int maxStops) {
        return findRoutes(start, end, maxStops, 0);// Call the recursive method to find routes
    }
    // Recursive method to find all possible routes with a maximum number of stops
    private int findRoutes(Node current, Node end, int maxStops, int stops) {
        if (stops > maxStops) return 0;// Stop if we've exceeded the maxStops
        int count = current.equals(end) && stops > 0 ? 1 : 0;// If we reach the destination, count this route

        // Iterate through all successors of the current node and explore further
        for (Node successor : graph.successors(current)) {
            count += findRoutes(successor, end, maxStops, stops + 1);
        }

        return count;// Return the total number of valid routes
    }
}
