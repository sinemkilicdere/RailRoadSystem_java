package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;
import com.ethic.engineering.railroad.helper.DefaultValueDigraph;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DFSConnectednessCheckerTest {
    @Test
    public void testConnectedness() {
        ValueDigraph graph = DefaultValueDigraph.graph;
        Node a = Node.of("A");
        Node c = Node.of("C");
        assertTrue(DFSConnectednessChecker.from(graph).isConnected(a, c));
    }
}