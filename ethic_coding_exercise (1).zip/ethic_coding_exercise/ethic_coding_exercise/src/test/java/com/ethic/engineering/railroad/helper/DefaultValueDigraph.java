package com.ethic.engineering.railroad.helper;

import com.ethic.engineering.railroad.domain.ValueDigraph;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class DefaultValueDigraph {

    public static final ValueDigraph graph;

    static {
        InputStream in = new ByteArrayInputStream("AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7".getBytes());
        graph = new TextParserValueDigraphBuilder(in).build();
    }
}
