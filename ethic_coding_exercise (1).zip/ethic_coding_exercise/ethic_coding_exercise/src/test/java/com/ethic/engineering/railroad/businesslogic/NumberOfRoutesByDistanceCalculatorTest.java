package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;
import com.ethic.engineering.railroad.helper.TextParserValueDigraphBuilder;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;

import static org.junit.jupiter.api.Assertions.*;

class NumberOfRoutesByDistanceCalculatorTest {

    private ValueDigraph createTestGraph() {
        String graphInput = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7";
        ByteArrayInputStream input = new ByteArrayInputStream(graphInput.getBytes());
        return new TextParserValueDigraphBuilder(input).build();
    }

    @Test
    void testNumberOfRoutes() {
        ValueDigraph graph = createTestGraph();
        NumberOfRoutesByDistanceCalculator calculator = new NumberOfRoutesByDistanceCalculator(graph);

        int routes = calculator.calculate(Node.of("C"), Node.of("C"), 30);
        assertEquals(7, routes); // Expected based on the problem statement
    }
}
