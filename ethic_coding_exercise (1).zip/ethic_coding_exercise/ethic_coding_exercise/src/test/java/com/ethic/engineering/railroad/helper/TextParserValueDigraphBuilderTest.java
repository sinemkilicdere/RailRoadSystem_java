package com.ethic.engineering.railroad.helper;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class TextParserValueDigraphBuilderTest {

    private final Node a = Node.of("A");
    private final Node b = Node.of("B");

    @Test
    void addEdgeWithValue() {
        ValueDigraph graph =
                new TextParserValueDigraphBuilder(getDefaultInputStream())
                        .addEdgeWithValue(a, b, 1d).build();
        assertTrue(graph.successors(a).contains(b));
    }

    @Test
    public void testDuplicatedEdgeShouldThrow() {
        assertThrows(IllegalArgumentException.class,
                () -> new TextParserValueDigraphBuilder(getDefaultInputStream())
                        .addEdgeWithValue(a, b, 1d)
                        .addEdgeWithValue(a, b, 1d)
                        .build());
    }

    @Test
    public void testZeroValueEdgeShouldThrow() {
        assertThrows(IllegalArgumentException.class,
                () -> new TextParserValueDigraphBuilder(getDefaultInputStream())
                        .addEdgeWithValue(a, b, 0d)
                        .build());
    }

    @Test
    public void testNegativeValueEdgeShouldThrow() {
        assertThrows(IllegalArgumentException.class,
                () -> new TextParserValueDigraphBuilder(getDefaultInputStream())
                        .addEdgeWithValue(a, b, -1d)
                        .build());
    }

    @Test
    public void testEquivalentToDefaultBuilder() {
        String text = "AB1";
        InputStream in = new ByteArrayInputStream(text.getBytes());

        IValueDigraphBuilder builder = new TextParserValueDigraphBuilder(in);
        ValueDigraph graph = builder.build();
        Node a = Node.of("A");
        Node b = Node.of("B");
        assertEquals(Set.of(b), graph.successors(a));
        assertEquals(Map.of(b, 1d), graph.successorWithValues(a));
        assertEquals(Collections.emptySet(), graph.successors(b));
    }

    @Test
    public void testDelimiter() {
        String text = "AB1,BC2";
        InputStream in = new ByteArrayInputStream(text.getBytes());

        IValueDigraphBuilder builder = new TextParserValueDigraphBuilder(in);
        ValueDigraph graph = builder.build();
        Node a = Node.of("A");
        Node b = Node.of("B");
        Node c = Node.of("C");
        assertEquals(Set.of(b), graph.successors(a));
        assertEquals(Set.of(c), graph.successors(b));
    }

    private InputStream getDefaultInputStream() {
        String text = "AC1";
        return new ByteArrayInputStream(text.getBytes());
    }

}