package com.ethic.engineering.railroad.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NodeTest {
    @Test
    public void testEqual() {
        Node a = Node.of("A");
        Node aDup = Node.of("A");

        assertEquals(a, aDup);
        assertEquals(aDup, a);
    }

    @Test
    public void testHashCode() {
        Node a = Node.of("A");
        Node aDup = Node.of("A");

        assertEquals(a.hashCode(), aDup.hashCode());
    }
}