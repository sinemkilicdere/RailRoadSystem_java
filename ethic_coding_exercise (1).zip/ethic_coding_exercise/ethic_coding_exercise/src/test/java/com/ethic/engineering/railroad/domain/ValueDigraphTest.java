package com.ethic.engineering.railroad.domain;

import com.ethic.engineering.railroad.helper.DefaultValueDigraph;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ValueDigraphTest {
    @Test
    public void testNodeNotInGraph() {
        assertThrows(IllegalArgumentException.class,
                () -> {
                    final ValueDigraph graph = DefaultValueDigraph.graph;
                    Node z = Node.of("Z");
                    graph.successors(z);
                });
    }
}