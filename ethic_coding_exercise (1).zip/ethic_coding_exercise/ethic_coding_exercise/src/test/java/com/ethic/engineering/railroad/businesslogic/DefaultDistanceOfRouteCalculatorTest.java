package com.ethic.engineering.railroad.businesslogic;

import com.ethic.engineering.railroad.domain.Node;
import com.ethic.engineering.railroad.domain.ValueDigraph;
import com.ethic.engineering.railroad.helper.TextParserValueDigraphBuilder;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class DefaultDistanceOfRouteCalculatorTest {

    private ValueDigraph createTestGraph() {
        String graphInput = "AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7";
        ByteArrayInputStream input = new ByteArrayInputStream(graphInput.getBytes());
        return new TextParserValueDigraphBuilder(input).build();
    }

    @Test
    void testValidRoute() {
        ValueDigraph graph = createTestGraph();
        DefaultDistanceOfRouteCalculator calculator = DefaultDistanceOfRouteCalculator.from(graph);

        List<Node> route = List.of(Node.of("A"), Node.of("B"), Node.of("C"));
        Optional<Double> distance = calculator.distanceOfRoute(route);

        assertTrue(distance.isPresent());
        assertEquals(9.0, distance.get());
    }

    @Test
    void testInvalidRoute() {
        ValueDigraph graph = createTestGraph();
        DefaultDistanceOfRouteCalculator calculator = DefaultDistanceOfRouteCalculator.from(graph);

        List<Node> route = List.of(Node.of("A"), Node.of("E"), Node.of("D"));
        Optional<Double> distance = calculator.distanceOfRoute(route);

        assertTrue(distance.isEmpty());
    }
}
