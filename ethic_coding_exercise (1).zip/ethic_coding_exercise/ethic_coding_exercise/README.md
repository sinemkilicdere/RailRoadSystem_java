**Disclaimer**

This Exercise has been created by Ethic to assess candidates technical fit, this exercise is
confidential, please do not share or distribute this exercise.

You may not use external libraries when solving this problem, you can use external
libraries/frameworks/tools for testing or building purposes. You can use the internet while solving this
problem. However, the work presented in your solution should be your own, without the help of any
other person and without another person reviewing the code you’re submitting.

**Objective**

The objective of this exercise are twofold:

* From Ethic’s point of view, this will help us evaluate how you approach solving a problem in a similar fashion to what you’d have to do on a day-to-day basis at work
* From the Candidate’s point of view, this will help you assess how Ethic’s requirements methodology is articulated and the typical work you might be doing

**Running the Code**

This project uses gradle to build and the source code uses java 21.
From command line you can use gradlew or gradlew.bat from project root directory.
e.g.,

    gradlew build

The application takes an input file to build the graph, then it runs a while loop to
read from stdin and handles the queries.

You can then run the application using the sample graph provided

    gradlew run --args="graph.txt"

###### Supported commands
    //Is node A connected to node B?
    $IC A B
    
    //Distance of a certain route
    $DOR ABC

    //Number Of Routes starting at C and ending at C with a maximum of 3 Stops
    $NORS C C 3
    
    //Number Of Routes from C to C with a Distance of less than 30 
    $NORD C C 30

    //Quit 
    $Q

#### Unit Tests
This project uses junit. To run unit tests,

    gradlew test


**Other comments and notes from candidate**
TODO: Add any comments or notes here

